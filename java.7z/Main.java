import java.time.LocalDate;


public class Main {
    public static void main(String[] args) {
        DatabaseManager dbm = new DatabaseManager();
       /* Klientas klientas = new Klientai(1, "Jonas", "Jonaitis", "jonas@gmail.com", 86624532, LocalDate(2023,10,13));
        dbm.pridetiKlienta(klientas);*/

    }
}
